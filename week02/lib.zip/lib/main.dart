import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.pinkAccent,
        appBar: AppBar(
          title: Text("Hello World"),
        ),
        body: Center(
          child: Image(
            image: AssetImage('images/treasure.jpg'),
          ),
        ),
      ),
    ),
  );
}